package com.example.textrecognitionapp

class MainActivityTest extends GroovyTestCase {
}
